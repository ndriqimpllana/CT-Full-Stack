# Event Center Website Assignment 



#Theme 
Event Center Website.
A center for events be that concerts, sports events, performing arts or just community events

Must have in the structure of the website

# Home Page 

I created the Home page that contains a banner that contains the centers slogan the a brief
history(Written by AI) about the center and it's contributions the the world of art and finally a section about the future events that will take place in the venue with respective links to the events page which is dedicated to upcoming events.
I used flexbox to style the cards for the future events and for the rest of the page as i find flexbox to be the best when it comes to making the page more responsive and compatible with different devices.
One of the biggest difficulties that i have had during the making of this site has been the navigation bar and making it compatible with different screen sizes and devices.
Also using media queries it took me a while until i understood how it works.
As per requirement i did make the navabr that works consistently across all pages and also it is compatible with different screen sizes.
# Bonus - I added the featured events section in the Home Page.


# Events Page 

In the events page I included 4 upcoming events with short descriptions(written by AI) with proper html structure with the use of semantic elements with images for each event.
I used flexbox to style the cards and also added some simple :hover effects to each card also added simple media queries to make the page adapt based on the screen size(far from perfect but i tried). 

# Menu Page

As required in the menu page i did create a table with the categories by using table headers and icluded items for each category i initially styled the table by using the colspan attribute and then used flexbox to make it more responsive with some light styling and a hover effect when going through the items.

# Location Page 

In the location page i did include the adress the hours and also embeded a address from google maps within the page. I used flexbox to style the page and make sure that the content is centered and looks good also used media queries to make sure it looks good with diferent screen sizes 


# Contact Us Page

In this page i built a contact form with name, email and message i made sure to add form validation in order to make sure that the required fields are filled. Also used



